var indexSectionsWithContent =
{
  0: "admr",
  1: "m",
  2: "admr",
  3: "m"
};

var indexSectionNames =
{
  0: "all",
  1: "files",
  2: "functions",
  3: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Files",
  2: "Functions",
  3: "Macros"
};

